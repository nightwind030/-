const lib = require('lib')({token: process.env.STDLIB_SECRET_TOKEN});

const key = 'giveaway'

function getEmbed(user, time, prize, drawSize) {
  return {
    type: 'rich',
    title: prize,
    description: [
      `React with ${process.env.EMOJI} to enter!`,
      `Time: ${time}s`,
      `Hosted by: <@${user}>`,
    ].join('\n'),
    color: 0x00ffff,
    footer: getEmbedFooter(drawSize),
  }
}

function getEmbedFooter(drawSize) {
  const s = drawSize === 1 ? "" : "s"
  return {
    text: `${drawSize} potential winner${s}`,
  }
}

async function stop(force) {
  
  // Get giveaway storage
  const giveaway = await lib.utils.kv['@0.1.16'].get({ key });
  if (!giveaway) return "No giveaway"
  
  // Check if the giveaway has finished
  const now = new Date()
  const finish = new Date(giveaway.finish)
  if (!force && now < finish) return "Giveaway hasn't finished"
  
  const winners = giveaway.winners;
  const winner = winners[Math.floor(Math.random() * winners.length)]
  
  // Send message
  const winningMessage = winners.length > 0
    ? `${process.env.EMOJI} Contratulations <@${winner}>, you have won **${giveaway.prize}** ${process.env.EMOJI}`
    : `${process.env.EMOJI} No winner of **${giveaway.prize}** today ${process.env.EMOJI}`
  
  await lib.discord.channels['@0.1.1'].messages.create({
    channel_id: giveaway.channel_id,
    content: winningMessage,
  });
  
  // Clean up
  await lib.utils.kv['@0.1.16'].clear({ key });
  
  // Update original message
  const message = await lib.discord.channels['@0.1.1'].messages.retrieve({
    message_id: giveaway.message_id,
    channel_id: giveaway.channel_id,
  });
  const { channel_id, id: message_id, content, embeds } = message
  const embed = embeds[0]
  
  // Update message
  await lib.discord.channels['@0.1.1'].messages.update({
    channel_id, message_id, content,
    embed: { ...embed, title: `[ENDED] ${embed.title}` },
  });
}

module.exports = {
  key,
  getEmbed,
  getEmbedFooter,
  stop,
}