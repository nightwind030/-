#🌟・SELECTMENU REACTION ROLE

This App is selectmenu reaction role, go on to each `attack.js`, `builder.js`, `design.js` & `partner.js`to get info how they works. But when you are duplicating remember that you have to make another selectmenu from ''https://autocode.com/embed' and they should have same data to make it work.

#🌟・HOW TO INSTALL

・Install App

・Fill PREFIX

・Fill Role IDs in `ENVIRONMENT VARIABLES`

・Link Bot

・Edit Message as your like and add more roles

・Use your prefix with setup

・You are good to go

#🌟・MADE BY

This app is made by @DeathManager#3948 in autocode discord server. If you need any help related to this app you can contact the person above.